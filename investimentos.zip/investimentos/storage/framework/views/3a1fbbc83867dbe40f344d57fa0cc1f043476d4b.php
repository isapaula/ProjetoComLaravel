<label class="<?php echo e($class ?? null); ?>">
    <span><?php echo e($label ?? $input ?? "ERRO"); ?></span>
    <?php echo Form::text($input, $value ?? null,$attributes); ?>

</label><?php /**PATH C:\wamp64\www\investimentos\resources\views/templetes/formulario/input.blade.php ENDPATH**/ ?>