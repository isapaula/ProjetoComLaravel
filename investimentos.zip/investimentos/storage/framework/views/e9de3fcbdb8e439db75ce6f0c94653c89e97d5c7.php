<label class="<?php echo e($class ?? null); ?> submit">
    <?php echo Form::submit($input); ?>

</label><?php /**PATH C:\wamp64\www\investimentos\resources\views/templetes/formulario/submit.blade.php ENDPATH**/ ?>