

<?php $__env->startSection('css-view'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-view'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo-view'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\investimentos\resources\views/user/dashboard.blade.php ENDPATH**/ ?>