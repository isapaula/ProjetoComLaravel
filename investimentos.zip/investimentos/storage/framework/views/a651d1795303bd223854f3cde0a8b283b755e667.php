

<?php $__env->startSection('css-view'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-view'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo-view'); ?>
    
<?php if(session('success')): ?>
<h3><?php echo e(session('success')['message']); ?></h3>
<?php endif; ?>
        


    <?php echo Form::open(['route' => 'user.store','method' => 'post', 'class' => 'form-padrao']); ?>

        <?php echo $__env->make('templetes.formulario.input', ['input' => 'cpf', 'attributes' =>['placeholder' => 'CPF']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('templetes.formulario.input', ['input' => 'name', 'attributes' =>['placeholder' => 'Name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('templetes.formulario.input', ['input' => 'phone', 'attributes' =>['placeholder' => 'Phone']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('templetes.formulario.input', ['input' => 'email', 'attributes' =>['placeholder' => 'E-mail']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('templetes.formulario.password', ['input' => 'password', 'attributes' =>['placeholder' => 'Senha']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('templetes.formulario.submit',['input' => 'Cadastrar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>


    <table class="default-table">
        <thead>
            <tr>
                <td>#</td>
                <td>CPF</td>
                <td>Nome</td>
                <td>Telefone</td>
                <td>Nascimento</td>
                <td>E-mail</td>
                <td>Status</td>
                <td>Permissao</td>
                <td>Menu</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->cpf); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->birth); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->status); ?></td>
                    <td><?php echo e($user->permission); ?></td>
                    <td>
                        <?php echo Form::open(['route'=>['user.destroy',$user->id],'method'=>'DELETE']); ?>

                        <?php echo Form::submit('Remover'); ?>

                        <?php echo Form::close(); ?>

                      
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templetes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\investimentos\resources\views/user/index.blade.php ENDPATH**/ ?>