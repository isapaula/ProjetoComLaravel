
    <nav id="principal">
        <ul>
            <li>
                <a href="<?php echo e(route('user.index')); ?>">
                    <i class="fa fa-user"></i>
                    <h3>Usuários</h3>
                </a>
            </li>
            <li>
            <a href="<?php echo e(route('instituition.index')); ?>">
                    <i class="fa fa-building" ></i>
                    <h3>Instituições</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <i class="fa fa-users"></i>
                    <h3>Grupos</h3>
                </a>
            </li>
        </ul>
    </nav>

<?php /**PATH C:\wamp64\www\investimentos\resources\views/templetes/menu-lateral.blade.php ENDPATH**/ ?>