<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Investindo</title>
    <?php echo $__env->yieldContent('css-view'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/stylesheet.css')); ?>">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">
<link  href="//netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('templetes.menu-lateral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="view-conteudo">
        <?php echo $__env->yieldContent('conteudo-view'); ?>
    </section>
    <?php echo $__env->yieldContent('js-view'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\investimentos\resources\views/templetes/master.blade.php ENDPATH**/ ?>