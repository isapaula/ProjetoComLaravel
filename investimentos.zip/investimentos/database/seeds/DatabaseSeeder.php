<?php

use Illuminate\Database\Seeder;
use App\Entities\User;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'cpf'     => '00055533369',
            'name'    => 'ingrid',
            'phone'   => '33656932',
            'birth'   => '2001-02-05',
            'gender'  => 'F',
            'email'   => 'ingrid@hotmail.com',
            'password' => env('PASSWORD_HASH') ? bcrypt('225678') : '225678' , 
        ]);
        // $this->call(UserSeeder::class);
    }
}
