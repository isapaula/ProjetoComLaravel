<?php

namespace App\Services;
use \Prettus\Validator\Contracts\ValidatorInterface;
use \Prettus\Validator\LaravelValidator;
use App\Repositories\UserRepository;
use App\Repositories\UserRepositoryEloquent;
use App\Validators\UserValidator;

class UserService
{
     private $repository;
     private $validator;

    public function __construct(UserRepository $repository, UserValidator $validator){
        $this->repository = $repository;
        $this->validator = $validator;
    }

    public function store($data){
        try {
            $this->validator->with($data)->passesOrFail(ValidatorInterface::RULE_CREATE);
            $usuario = $this->repository->create($data);
            return [
                'success' => true,
                'message' => 'Usuario cadastrado',
                'data'    => $usuario,
            ];
        
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Usuario nao cadastrado',
            ];
        }
    }
    public function update(){

    }
    public function delete($user_id){
        try {
            
            $this->repository->delete($user_id);
            return [
                'success' => true,
                'message' => 'Usuario removido',
                'data'    => null,
            ];
        
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Usuario nao cadastrado',
            ];
        }
    }

}


?>