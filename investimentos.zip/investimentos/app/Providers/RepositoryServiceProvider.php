<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->app->bind(\App\Repositories\UserRepository::class, \App\Repositories\UserRepositoryEloquent::class);
        $this->app->bind(\App\Repositories\UsuaRepository::class, \App\Repositories\UsuaRepositoryEloquent::class);
        $this->app->bind(\App\Repositories\AulaRepository::class, \App\Repositories\AulaRepositoryEloquent::class);
        $this->app->bind(\App\Repositories\TesteRepository::class, \App\Repositories\TesteRepositoryEloquent::class);
        $this->app->bind(\App\Repositories\Teste2Repository::class, \App\Repositories\Teste2RepositoryEloquent::class);
        $this->app->bind(\App\Repositories\InstituitionRepository::class, \App\Repositories\InstituitionRepositoryEloquent::class);
        //:end-bindings:
    }
}
