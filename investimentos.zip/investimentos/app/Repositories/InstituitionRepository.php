<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface InstituitionRepository.
 *
 * @package namespace App\Repositories;
 */
interface InstituitionRepository extends RepositoryInterface
{
    //
}
