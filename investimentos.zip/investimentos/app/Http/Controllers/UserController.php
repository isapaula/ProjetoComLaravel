<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Services\UserService;
use App\Repositories\UserRepository;
use App\Repositories\UserRepositoryEloquent;
use App\Validators\UserValidator;
use \Prettus\Validator\Contracts\ValidatorInterface;



class UserController extends Controller
{
    protected $service;
    protected $repository;

    public function __construct(UserRepository $repository, UserService  $service){

        $this->repository = $repository;
        $this->service = $service;


    }
    
    public function index()
    {
        $users = $this->repository->all();

        return view('user.index',[
            'users' =>$users
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request = $this->service->store($request->all());
        $usuario = $request['success'] ? $request['data'] : null;

        session()->flash('success',[
            'success' => $request['success'],
            'message' =>$request['message']
        ]);
  
        return view('user.index', [
            'usuario' => $usuario,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $request = $this->service->delete($id);
        
        session()->flash('success',[
            'success' => $request['success'],
            'message' =>$request['message']
        ]);
  
        return redirect()->route('user.index');
    }
}
