
    <nav id="principal">
        <ul>
            <li>
                <a href="{{route('user.index')}}">
                    <i class="fa fa-user"></i>
                    <h3>Usuários</h3>
                </a>
            </li>
            <li>
            <a href="{{route('instituition.index')}}">
                    <i class="fa fa-building" ></i>
                    <h3>Instituições</h3>
                </a>
            </li>
            <li>
                <a href="">
                    <i class="fa fa-users"></i>
                    <h3>Grupos</h3>
                </a>
            </li>
        </ul>
    </nav>

